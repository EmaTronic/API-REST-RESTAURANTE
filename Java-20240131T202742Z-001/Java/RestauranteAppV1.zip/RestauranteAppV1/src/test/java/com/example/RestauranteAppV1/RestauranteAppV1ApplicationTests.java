package com.example.RestauranteAppV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestauranteAppV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
